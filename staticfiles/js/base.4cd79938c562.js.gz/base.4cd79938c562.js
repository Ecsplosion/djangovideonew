// let height = screen.height;
// console.log("Height: "+ height)
// const mainBody = document.getElementsByClassName("main-body")[0]
// mainBody.setAttribute("style", `height: ${547}px`)