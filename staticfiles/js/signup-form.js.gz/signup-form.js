document.getElementById("password1").readOnly=true;
document.getElementById("password2").readOnly=true;